<?php
error_reporting(0);
//connect
$conn = mysql_connect('localhost', 'cutelove_data', '6Qw+[h,J9+Tz') or die('Không thể kết nối CSDL');
mysql_select_db('cutelove_data');
mysql_query("UPDATE `users` SET `baodanh` = '0', `nhanhopqua` = '0', `chanchat`='0'");
mysql_query("DELETE FROM `nhiemvu_user`");
mysql_query("DELETE FROM `naruto_nhiemvu`");
?>