<?php
defined('_IN_JOHNCMS') or die('Error: restricted access');
if (isset($_COOKIE['the']))
{
$the = $_COOKIE['the'];
}
elseif (!$is_mobile)
{
$the = 'web';
} else {
$the = 'wap';
}
////////CODE WEB Ở ĐÂY
if ($the == 'web')
{
echo'</div>';
echo'</div>';
if (!empty($cms_ads[0]))
echo '<div class="func"><b>' . $cms_ads[0] . '</b></div>';
echo'
<div class="clearfix"></div></div><br></div></div><br></div>';
echo'<div class="left_b_bottom"><div class="right_b_bottom"><div class="footer"><div class="left_bottom"></div><div class="right_bottom"></div></div></div></div><div class="copyright">';
echo'<div class="on">';
echo'</div>';
echo'<b>Phát triển bởi tất cả thành viên 8vui.Top</br>
Thành Lập ngày:<br/>24/5/2016™</b>';
// NÚT  TOP-UP

//thanh trượt#E4DDDF
echo '<style type="text/css">
::-webkit-scrollbar {
width:11px;height:11px;
}
::-webkit-scrollbar-thumb {
background:#8DA59E;
border-radius:10px;
}
</style>';
//di chuyễn vào link - trái tim
echo '<style type="text/css">
a:hover 
{text-decoration:none;
color:#D570EE;
text-decoration:none;
font-weight:bold;
background-image:url("/icon/timbay.gif");
}
</script>';
}
////////CODE WAP Ở ĐÂY
if ($the == 'wap')
{
echo'</div>';
echo'</div>';
if (!empty($cms_ads[0]))
echo '<div class="func"><b>' . $cms_ads[0] . '</b></div>';
echo'
<div class="clearfix"></div></div><br></div></div><br></div>';
echo'<div class="left_b_bottom"><div class="right_b_bottom"><div class="footer"><div class="left_bottom"></div><div class="right_bottom"></div></div></div></div><div class="copyright">';
echo'<div class="on">';
echo'</div>';
echo'<b>Phát triển bởi tất cả thành viên 8vui.Top</br>
Thành Lập ngày:<br/>24/5/2016™</b>';
}
?>
                            