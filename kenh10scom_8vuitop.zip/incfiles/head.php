<?php
defined('_IN_JOHNCMS') or die('Error: restricted access');


ob_start();
session_start();
$headmod = isset($headmod) ? mysql_real_escape_string($headmod) : '';
$textl = isset($textl) ? $textl : $set['copyright'];
/*
-----------------------------------------------------------------
Выводим HTML заголовки страницы, подключаем CSS файл
-----------------------------------------------------------------
*/

header("Expires: " . date("r",  time() + 60));
echo '<?xml version="1.0" encoding="utf-8"?>' . "\n" .
"\n" . '<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">' .
"\n" . '<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="vn"  lang="vn">' .
"\n" . '<head>' .
"\n" . '<meta charset="utf-8">' .
"\n" . '<meta name="robots" content="index,follow" />' .
"\n" . '<meta name="geo.region" content="vn" />' .
"\n" . '<meta http-equiv="Content-Style-Type" content="text/css" />' .
"\n" . '<meta name="Generator" content="8vui.top, http://8vui.top" />' . // ВНИМАНИЕ!!! Данный копирайт удалять нельзя
(!empty($set['meta_key']) ? "\n" . '<meta name="keywords" content="' . $set['meta_key'] . '" />' : '') .
(!empty($set['meta_desc']) ? "\n" . '<meta name="description" content="' . $set['meta_desc'] . '" />' : '') .
"\n" . '<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css"><link rel="stylesheet" href="/giaodien/stylenew.css" type="text/css" />' .
"\n" . '<link rel="shortcut icon" href="' . $set['homeurl'] . '/icon.png" />' .
"\n" . '<link rel="alternate" type="application/rss+xml" title="RSS | ' . $lng['site_news'] . '" href="' . $set['homeurl'] . '/rss/rss.php" />' .
"\n" . '<title>' . $textl . '</title>' .
"\n" . '<script type="text/javascript" src="/pages/jquery-2.1.4.min.js"></script><script type="text/javascript" src="/pages/jquery.validate.min.js"></script><script type="text/javascript" src="/pages/smoothscroll.js"></script><script type="text/javascript" src="http://ajax.microsoft.com/ajax/jquery.validate/1.7/jquery.validate.min.js"></script>'.
"\n" . '</head><body>' . core::display_core_errors();

if ($user_id) {
//--- Mod Chatbox v3 ---//
echo "<script>
$(document).ready(function(){
$(\"#datachat\").load(\"chemgio.php\");
var refreshId = setInterval(function() {
$(\"#datachat\").load('/chemgio.php');
$(\"#datachat\").slideDown(\"slow\");
}, 15000);
$(\"#shoutbox\").validate({
debug: false,
submitHandler: function(form) {
$.post('/chemgio.php', $(\"#shoutbox\").serialize(),function(chatoutput) {
$(\"#datachat\").html(chatoutput);
});
$(\"#msg\").val(\"\");
}
});
});
</script>";
}
/*
-----------------------------------------------------------------
Рекламный модуль
-----------------------------------------------------------------
*/










$cms_ads = array();
if (!isset($_GET['err']) && $act != '404' && $headmod != 'admin') {
$view = $user_id ? 2 : 1;
$layout = ($headmod == 'mainpage' && !$act) ? 1 : 2;
$req = mysql_query("SELECT * FROM `cms_ads` WHERE `to` = '0' AND (`layout` = '$layout' or `layout` = '0') AND (`view` = '$view' or `view` = '0') ORDER BY  `mesto` ASC");
if (mysql_num_rows($req)) {
while (($res = mysql_fetch_assoc($req)) !== FALSE) {
$name = explode("|", $res['name']);
$name = htmlentities($name[mt_rand(0, (count($name) - 1))], ENT_QUOTES, 'UTF-8');
if (!empty($res['color'])) $name = '<span style="color:#' . $res['color'] . '">' . $name . '</span>';
$font = $res['bold'] ? 'font-weight: bold;' : FALSE;
$font .= $res['italic'] ? ' font-style:italic;' : FALSE;
$font .= $res['underline'] ? ' text-decoration:underline;' : FALSE;
if ($font) $name = '<span style="' . $font . '">' . $name . '</span>';
@$cms_ads[$res['type']] .= '<a href="' . ($res['show'] ? functions::checkout($res['link']) : $set['homeurl'] . '/go.php?id=' . $res['id']) . '">' . $name . '</a><br/>';
if (($res['day'] != 0 && time() >= ($res['time'] + $res['day'] * 3600 * 24)) || ($res['count_link'] != 0 && $res['count'] >= $res['count_link']))
mysql_query("UPDATE `cms_ads` SET `to` = '1'  WHERE `id` = '" . $res['id'] . "'");
}
}
}
if (isset($cms_ads[0])) echo $cms_ads[0];
echo'<div class="body_body">';
echo'<div class="left_top"></div><div class="bg_top"><div class="right_top"></div></div>';
echo'<div class="body-content">';
echo'<div class="a" align="center">';
echo'<a href="/index.php"><img src="/images/logonaruto.png" width="223" height="83"/></a>';
echo'</div>';
echo'<div class="link-more">';
echo'<div class="h">';
if ($user_id) {
echo'<table width="100%" border="0" cellspacing="0"><tr class="menu">';
echo'</td><td width="25%">';
echo'<a href="' . $set['homeurl'] .'/nhom/index.php">Clan</a>';
echo'</td>
<td width="25%">';
$a = mysql_query("SELECT * FROM `thongbao` WHERE `ok` = '1' and `user` = '" . $user_id . "'");
$c = mysql_num_rows($a);
echo'<a href="' . $set['homeurl'] . '/thongbao.html">Thông báo';
if($c >=1){
echo ' <span class="label label-success">'.$c.'</span>';
}
echo'</a>';
echo'</td><td width="25%"">';
$new_mail = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_mail` LEFT JOIN `cms_contact` ON `cms_mail`.`user_id`=`cms_contact`.`from_id` AND `cms_contact`.`user_id`='$user_id' WHERE `cms_mail`.`from_id`='$user_id' AND `cms_mail`.`sys`='0' AND `cms_mail`.`read`='0' AND `cms_mail`.`delete`!='$user_id' AND `cms_contact`.`ban`!='1' AND `cms_mail`.`spam`='0'"), 0);
echo'<a href="' . $set['homeurl'] . '/mail/new.html">Hộp thư';
if ($new_mail) $list[] = ' <span class="label label-success">' . $new_mail . ' </span>';
if (!empty($list)) echo '' . functions::display_menu($list, ', ') . '';
echo'</a>';
echo'</td></tr></table>';
echo'<div class="body">';
}
if (!$user_id) {

echo'<table width="100%" border="0" cellspacing="0"><tr class="menu"><td width="32%">';
echo'<a href="' . $set['homeurl'] . '/dangnhap.html">Đăng nhập</a>';
echo'</td><td width="32%">';
echo'<a href="' . $set['homeurl'] . '/dangki.html">Đăng kí</a>';
echo'</td><td width="35%">';
echo'<a href="' . $set['homeurl'] . '/forum/">Diễn đàn</a>';
echo'</td></tr></table>';
echo'<div class="body">';
}
echo'<div id="box_login_ads">';
if ($user_id) {
$hienluotboss = 1;
$hienluotboss2 = 2;
$time = time();
//--SYS--//
include 'sys/daugia.php';
include 'sys/taixiu.php';
include 'sys/pet.php';
include 'sys/check.php';
include 'sys/password_2.php';
include 'sys/hsd.php';
include 'sys/vitri.php';
include 'sys/kethon.php';
include 'sys/gioithieu.php';
//include 'sys/house.php';
include 'sys/thongbaovatnuoi.php';
include 'sys/thongbaolambanh.php';
//include 'sys/luotchoi.php';
//include 'sys/luotbatdau.php';
//-Avatar-//
echo'<div class="tmn"><table cellpadding="0" cellspacing="0" width="100%" border="0" style="table-layout:fixed;word-wrap: break-word;"><tbody><tr><td align="center" width="100">';
       echo' <center><a href="/member/'.$user_id.'.html"><label style="display: inline-block;text-align: center;"><b style="font-size: 9px;color:red;font-weight:bold;text-align: center;">'.$login.'</b><br><img src="/avatar/'.$user_id.'.png"></label></a></center>';
echo'</td><td style="color:brown;font-size:11px;" class="data-user-left">
<div style="margin:3px;"><img class="padding-r-5 icon-m-o3" src="/icon/xu.png"> '.number_format($datauser['xu']).'&#160;Xu</div>
<div style="margin:3px;"><img class="padding-r-5" style="vertical-align:-2px" src="/icon/vnd.png"> '.number_format($datauser['vnd']).'&#160;Lượng</div>
<div style="margin:3px;"><img class="padding-r-5" style="vertical-align:-2px" src="/icon/hp.png"> '.number_format($datauser['hp']).' / '.number_format($datauser['hpfull']).' HP</div>
<div style="margin:3px;"><img class="padding-r-5" style="vertical-align:-2px" src="/icon/iconxoan/iconpk.png"> '.number_format($datauser['sucmanh']).' SM</div>

</td><td style="color:brown;font-size:11px;" valign="top">
<div style="margin:3px;"><img class="padding-r-5 icon-m-o3" src="/icon/icontuido.png"><a href="/ruong"> Rương</a></div>
<div style="margin:3px;"><img class="padding-r-5 icon-m-o3" src="/icon/user.png"><a href="/users/profile.php"> Cá nhân</a></div>
<div style="margin:3px;"><img class="padding-r-5 icon-m-o3" src="/icon/iconHome.gif"><a href="/sanbay/dancu/house.php"> Nhà</a></div>
<div style="margin:3px;"><img class="padding-r-5 icon-m-o3" src="/icon/iconexit.png"><a href="/exit.php"> Đăng xuất</a></div></td></tr></tbody></table></div>';
if ($rights>=6) {
$donhang=mysql_num_rows(mysql_query("SELECT * FROM `chotroi` WHERE `duyet`='0'"));
if ($donhang) {
echo '<div class="menu"><center><a href="/shop/chotroi.php?act=duyet"><font color="green">Có <b>'.$donhang.'</b> đơn hàng cần được phê duyệt</font></a></center></div>';
}
}
}
/////////////////////////////
if ($user_id) {
if (time()>$datauser['timehopqua']+3600*24) {
echo '<div class="list1"><img src="/images/qua.png" alt="Nhận quà"> <a href="/index.php?hopqua"><b>Bạn nhận được hộp quà tự hệ thống</b></a>';
if (isset($_GET['hopqua'])) {
$randxu = rand(50000, 500000);
mysql_query("UPDATE `users` SET `xu` = `xu` + '".$randxu."', `timehopqua` = '".time()."' WHERE `id` = '".$user_id."'");
echo '<br/><b>Bạn nhận được <font color="red">'.$randxu.' xu</font> từ hộp quà</b>';
}
echo '</div>';
}
if (time()>$datauser['timequaon']+60*15) {
echo '<div class="list1"><img src="/images/qua.png" alt="Nhận quà"> <a href="/index.php?quaonline"><b>Bạn nhận được quà online tự hệ thống</b></a>';
if (isset($_GET['quaonline'])) {
$randxu = rand(10000, 200000);
mysql_query("UPDATE `users` SET `xu` = `xu` + '".$randxu."', `timequaon` = '".time()."' WHERE `id` = '".$user_id."'");
echo '<br/><b>Bạn nhận được <font color="red">'.$randxu.' xu</font> từ quà online</b>';
}
echo '</div>';
}
}



echo'<div id="box_forums"><br/>';
$sql = '';
$set_karma = unserialize($set['karma']);
if ($user_id) {
// Фиксируем местоположение авторизованных
if (!$datauser['karma_off'] && $set_karma['on'] && $datauser['karma_time'] <= (time() - 86400)) {
$sql .= " `karma_time` = '" . time() . "', ";
}
$movings = $datauser['movings'];
if ($datauser['lastdate'] < (time() - 300)) {
$movings = 0;
$sql .= " `sestime` = '" . time() . "', ";
}
if ($datauser['place'] != $headmod) {
$movings;
$sql .= " `place` = '" . mysql_real_escape_string($headmod) . "', ";
}
if ($datauser['browser'] != $agn)
$sql .= " `browser` = '" . mysql_real_escape_string($agn) . "', ";
$totalonsite = $datauser['total_on_site'];
if ($datauser['lastdate'] > (time() - 300))
$totalonsite = $totalonsite + time() - $datauser['lastdate'];
mysql_query("UPDATE `users` SET $sql
`movings` = '$movings',
`total_on_site` = '$totalonsite',
`lastdate` = '" . time() . "'
WHERE `id` = '$user_id'
");
} else {
// Фиксируем местоположение гостей
$movings = 0;
$session = md5(core::$ip . core::$ip_via_proxy . core::$user_agent);
$req = mysql_query("SELECT * FROM `cms_sessions` WHERE `session_id` = '$session' LIMIT 1");
if (mysql_num_rows($req)) {

// Если есть в базе, то обновляем данные
$res = mysql_fetch_assoc($req);
$movings = ++$res['movings'];
if ($res['sestime'] < (time() - 300)) {
$movings = 1;
$sql .= " `sestime` = '" . time() . "', ";
}
if ($res['place'] != $headmod) {
$sql .= " `place` = '" . mysql_real_escape_string($headmod) . "', ";
}
mysql_query("UPDATE `cms_sessions` SET $sql
`movings` = '$movings',
`lastdate` = '" . time() . "'
WHERE `session_id` = '$session'
");
} else {
// Если еще небыло в базе, то добавляем запись
mysql_query("INSERT INTO `cms_sessions` SET
`session_id` = '" . $session . "',
`ip` = '" . core::$ip . "',
`ip_via_proxy` = '" . core::$ip_via_proxy . "',
`browser` = '" . mysql_real_escape_string($agn) . "',
`lastdate` = '" . time() . "',
`sestime` = '" . time() . "',
`place` = '" . mysql_real_escape_string($headmod) . "'
");
}
}
/* BOT ONLINE */
mysql_query("UPDATE `users` SET $sql `total_on_site` = '$totalonsite', `lastdate` = ". time() . " WHERE `id` = '2'");
mysql_query("UPDATE `users` SET $sql `total_on_site` = '$totalonsite', `lastdate` = ". time() . " WHERE `id` = '11'");
mysql_query("UPDATE `users` SET $sql `total_on_site` = '$totalonsite', `lastdate` = ". time() . " WHERE `id` = '22'");
mysql_query("UPDATE `users` SET $sql `total_on_site` = '$totalonsite', `lastdate` = ". time() . " WHERE `id` = '33'");
mysql_query("UPDATE `users` SET $sql `total_on_site` = '$totalonsite', `lastdate` = ". time() . " WHERE `id` = '44'");
mysql_query("UPDATE `users` SET $sql `total_on_site` = '$totalonsite', `lastdate` = ". time() . " WHERE `id` = '908'");
/* END BOT ONLINE */
if(empty($datauser['timethuhoachkhe'])) {
mysql_query("UPDATE `users` SET `timethuhoachkhe` = '".$time."' where `id` = '" . $user_id . "'");
}
if ($ban){
if ($textl!='Nhà Tù') {
header('Location: /ngoaio/nhatu.php');
exit;
}
}
?>
                            
                            
                            
                            
                            
                            
                            
                            
                            