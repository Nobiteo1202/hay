<?php
	if (empty($datauser['password_2'])) {
		echo '<div class="tmn">Xin mời các bạn vào thiết lập <a href="/users/password_2.php"><b style="color:red">Mật khẩu cấp 2</b></a></div>';
	} else {
		$_SESSION['password_2'] = isset($_SESSION['password_2']) ? $_SESSION['password_2'] : '';
		if (empty($_SESSION['password_2']) || $_SESSION['password_2'] != $datauser['password_2']) {
			//$_SESSION['count_false'] = 0;
			echo '<div class="menu">';
			/*if ($_SESSION['count_false'] >= 10) {
				//xử lý check
			}*/
			if (isset($_POST['xacthuc'])) {
				$password_2 = functions::checkout($_POST['password_2']);
				$password_2 = md5(md5($password_2));
				if (empty($password_2) || $password_2 != $datauser['password_2']) {
					//$_SESSION['count_false']++;
					echo '<div class="rmenu">Sai mật khẩu cấp 2</div>';
				} else {
					$_SESSION['password_2'] = $password_2;
					header('Location: /index.php');
					exit;
				}
			}
			echo '<form method="post"><input type="password" name="password_2" placeholder="Nhập mật khẩu cấp 2"> <input name="xacthuc" type="submit" value="Xác thực"></form>
			</br> Nếu quên mật khẩu cấp 2 </br>Soạn Tin Nhắn :<b> ON 8VUI PASS2 </b>gửi <b>8085</b></br>Lưu ý : dùng số điện thoại kích hoạt của tài khoản <b>'.$datauser['name'].'</b> ';
			include_once('/home4/cutelover/public_html/incfiles/end.php');
			exit;
		}
	}
	
?>