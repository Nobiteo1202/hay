<script type="text/javascript"> 
$('#p').click(function() {  
$('#pp').toggle('fast','linear');  
}); 
$('#b').click(function() {  
$('#bb').toggle('fast','linear');  
}); 
$('#ps').click(function() {  
$('#pps').toggle('fast','linear');  
}); 
$('#bs').click(function() {  
$('#bbs').toggle('fast','linear');  
}); 
$('#c').click(function() {  
$('#cc').toggle('fast','linear');  
}); 
</script>