<script type="text/javascript"> 
$('#ok').click(function() {  
$('#oke').toggle('fast','linear');  
}); 
$('#fuck').click(function() {  
$('#fucke').toggle('fast','linear');  
}); 
$('#test').click(function() {  
$('#tests').toggle('fast','linear');  
}); 
$('#testx').click(function() {  
$('#testxx').toggle('fast','linear');  
}); 
</script>