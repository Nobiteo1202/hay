<?php
if($user_id){ 
echo '<div class="phdr"><i class="fa fa-home"></i><font color="white"><b> Trung Tâm Thành Phố </b></font></div>';
echo'<div class="list1" style="font-size: 10px;font-weight: bold;"><link rel="stylesheet" type="text/css" href="/icon/stylexoan.css">
<table style="width:100%" border="0" cellspacing="0">

  <tr>
    <td style="text-align: center;"><a href="/farm/?xem"><img src="/icon/iconfarm.png" alt="icon" /><br/>Farm</a></td>
    <td style="text-align: center;"><a href="/boss"><img src="/icon/iconxoan/boss.png" alt="icon" width="34px" /><br/>Boss</a></td> 
    <td style="text-align: center;"><a href="/khugiaitri/"><img src="/images/giaitri.png" alt="icon" /><br/>Giải trí</a></td>
  </tr>

<tr>
<td style="text-align: center;"><a href="/khugiaitri/cauca/"><img src="/images/sinhthai.png" alt="icon" /><br/>Câu Cá</a></td>
    <td style="text-align: center;"><a href="/sanbay/dancu/"><img src="/icon/dancu.png" alt="icon" /><br/>Dân Cư</a></td> <td style="text-align: center;"><a href="/sanbay/"><img src="/images/sanbay.png" alt="icon" /><br/>Sân bay</a></td>
  </tr>

<tr> 
<td style="text-align: center;"><a href="/congvien/"><img src="/images/congvien.png" alt="icon"/><br/>Công Viên</a></td> <td style="text-align: center;"><a href="/shop/"><img src="/images/muasam.png" alt="icon"/><br/>Mua sắm</a></td> <td style="text-align: center;"><a href="/shop/chotroi.php"><img src="/icon/iconxoan/iconchotroi.png"alt="icon" width="34px"/><br/>Chợ Trời</a></td></tr>

<tr> 
<td style="text-align: center;"><a href="/sukien/naruto/index.php"><img src="/icon/iconxoan/khusk.png" width="34" alt="icon" /><br/>Sự Kiện</a></td> <td style="text-align: center;"><a href="/atm/"><img src="/icon/iconxoan/khuatm.png" width="34" alt="icon" /><br/>ATM</a></td> <td style="text-align: center;"><a href="/ngoaio"><img src="/icon/iconxoan/ngoaio.png"alt="icon" width="35px" /><br/>Ngoại ô</a></td></tr>

<tr> 
<td style="text-align:center;"><a href="/users/gioithieu.php"><img src="/icon/gt.png"alt="icon" width="34px"/><br/>Giới thiệu</a></td>
<td style="text-align:center;"><a href="/ranking/index.php"><img src="/icon/rank.png"alt="icon" width="34px"/><br/>Đấu Rank</a></td>

</tr>
</table>
</div>';
 }
?>