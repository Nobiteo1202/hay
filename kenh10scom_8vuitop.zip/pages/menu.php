<?php
if ($user_id) {
$list = array();
$new_sys_mail = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_mail` WHERE `from_id`='$user_id' AND `read`='0' AND `sys`='1' AND `delete`!='$user_id';"), 0);
if ($new_sys_mail) $list[] = '<a href="' . $home . '/mail/index.php?act=systems">&nbsp;&nbsp;<img src="/mail/images/thongbaomoi.gif"><font color="red"> Bạn có ' . $new_sys_mail . ' thông báo</font></a>';
if (!empty($list)) echo'' . functions::display_menu($list, ', ') . '';
}
include('map.php');
echo'<div class="box_list_parent_index">';

//chat box ajax
if ($user_id) {
if ($datauser['chanchat'] == 1)
{
echo '<div class="rmenu">Bạn đã bị chặn chat...</div>';
}
else
{
//--Phòng Chát--//
echo '<div class="phdr">• Chém gió</b></div><div class="mainblok">';
$refer = base64_encode($_SERVER['REQUEST_URI']);
$token = mt_rand(1000, 100000);
$_SESSION['token'] = $token;
echo '<div class="list1"><form name="shoutbox" id="shoutbox" action="/guestbook/index.php?act=say" method="post">'.bbcode::auto_bb('shoutbox', 'msg').'<div class="list1"><textarea  style="border-left:2px solid #44B6AE !important;" placeholder="Vui lòng viết tiếng việt có dấu để tôn trọng người đọc" id="msg" name="msg" class="form-control"></textarea><input type="hidden" name="ref" value="'.$refer.'"/><input type="hidden" name="token" value="'.$token.'"><br /><button type="submit" name="submit"><i class="fa fa-pencil" aria-hidden="true"></i> ' . $lng['sent'] . '</button></form></div></div>';
}
echo '<div id="datachat"></div>';

}
//--Kết thúc Phòng Chát//
/*echo '<script src="/pages/ajax.js"></script>';
echo '<div class="phdr"><b><i class="glyphicon glyphicon-envelope"></i> Phòng chat • <a href="/pages/faq.php?act=smileys">Smileys</a></b>
</div>';
$refer = base64_encode($_SERVER['REQUEST_URI']);
$token = mt_rand(1000, 100000);
$_SESSION['token'] = $token;
echo '<table cellpadding="0" cellspacing="0" width="99%" border="0" style="table-layout:fixed;word-wrap: break-word;">
<tbody><tr><td width="48px;" class="blog-avatar"><img src="/avatar/'.$user_id.'.png"  align="top">&nbsp;</td><td style="vertical-align: bottom;"><table cellpadding="0" cellspacing="0">
<tbody><tr><td class="current-blog" rowspan="2" style="">
<div class="blog-bg-left"><img src="/giaodien/images/left-blog.png"></div><div class="newsx">
<form id="form" method="POST">
<textarea type="text" placeholder="Chém vui vẻ!" id="postText" name="msg" class="form-control"></textarea>
<button name="submit" type="submit" id="submit" class="nut">Gửi</button>'.($rights >= 3? ' <a href="/congvien/botpanel.php">[BOT]</a> ': '').'
<input type="hidden" name="token" value="' . $token . '"/>
</form>
</div></td></tr></tbody></table></td></tr></tbody></table>';
}
echo '<div id="alert"></div><div id="postText"></div><div id="idChat"></div>';
}*/
//--Kết thúc Phòng Chát//
if ($user_id) {
echo'<div class="phdr"><i class="fa fa-book"></i> Bài Viết Mới</div>';
echo'<a id="fuck"><div class="omenu"><center><font color="green"><b>[ Xem bài viết mới nhất - trung tâm 8Vui.Top ]</b></font></b></center></div></a><div id="fucke" style="display: none;">';
$tong = mysql_result(mysql_query("SELECT COUNT(*) FROM `forum` WHERE `type` = 't' and kedit='0' AND `close`!='1'"), 0);
$req = mysql_query("SELECT * FROM `forum` WHERE `type` = 't' and kedit='0' AND `close`!='1' ORDER BY `time` DESC LIMIT $start, $kmess");
while ($arr = mysql_fetch_array($req)) {
$q3 = mysql_query("select `id`, `refid`, `text` from `forum` where type='r' and id='" .$arr['refid'] . "'");
$razd = mysql_fetch_array($q3);
$q4 = mysql_query("select `id`, `refid`, `text` from `forum` where type='f' and id='" .$razd['refid'] . "'");
$frm = mysql_fetch_array($q4);

$trang4 = mysql_query("SELECT * FROM `forum_thank` WHERE `topic` = '" . ($arr['id'] + 1) . "'");
$trang5 = mysql_num_rows($trang4);

$nikuser = mysql_query("SELECT `from`,`id`, `time` FROM `forum` WHERE `type` = 'm' AND `close` != '1' AND `refid` = '" . $arr['id'] . "'ORDER BY time DESC");
$colmes1 = mysql_num_rows($nikuser);
$cpg = ceil($colmes1 / $kmess);
$nam = mysql_fetch_array($nikuser);

echo is_integer($i / 2) ? '<div class="baiviet1" style="padding-bottom: 15px;">' : '<div class="baiviet2" style="padding-bottom: 15px;">';

echo '<img src="/avatar/'.$arr['user_id'].'.png" alt="'.$gres['name'].'" class="avatar_vina"/></br>';

echo ' <img src="images/' . ($arr['edit'] == 1 ? 'tz' : 'np') . '.gif" alt=""/> ';
if ($arr['vip'] == 1) echo '<b>';
if ($arr['realid'] == 1)
echo ' <img src="images/rate.gif" alt=""/> ';

echo ' <a href="'.$home.'/forum/' . $arr['id'] . '.html">' . functions::smileys($arr['text']) . '</a>';
if ($trang5 !== 0) echo '<font color="red"> [♥' . $trang5. ']</font>';
if ($arr['vip'] == 1) echo '</b> <img src="/images/hot.gif"/>';
if (!empty ($nam['from'])) {
echo ' <br/></br><font style="font-size:11px"> Bình luận mới : <b>' . $nam['from']. '</b> - Tổng : ' . $colmes1 . ' Bình Luận';
echo ' </font>';
}
echo '</div>';

$i++;
}
//////
$ddvn=mysql_query("SELECT * FROM `forum` WHERE `type`='f' ");
While($f=mysql_fetch_array($ddvn)){
Echo'<div class="phdr"><i class="fa fa-cubes"></i> <b>'.$f['text'].'</b></div>';
$ddvn1=mysql_query("SELECT * FROM `forum` WHERE `type`='r' AND `refid`='".$f['id']."' ");
while($r=mysql_fetch_array($ddvn1)){
echo'<div class="menuvj"><i class="fa fa-arrow-circle-right" style="color:#3c763d"></i> <a href="/forums/'.$r['id'].'.html"><b><font color="2c5170">'.$r['text'].'</font></b></a><br/>';
if($r['soft']) echo '<i class="fa fa-hand-o-right" style="color:#3c763d"></i> <small>'.$r['soft'].'</small><div class="sub"></div>';

$ddvn2=mysql_query("SELECT * FROM `forum` WHERE `type`='t' AND `refid`='".$r['id']."' LIMIT 2");
$i=1;
While($t=mysql_fetch_array($ddvn2)){
if ($t['vip'] == 1)
echo '<b>';
if ($t['indam'] == 1)
echo '<b>';
echo '<i class="fa fa-comments" style="color:#3c763d"></i> <a href="'.$home.'/forum/'.$t['id'].'.html"><span style="size:8px;">' .$t['text'] . '</span></a>';
if ($t['indam'] == 1)
echo '</b>';
if ($t['vip'] == 1)
echo '</b> <img src="../images/smileys/simply/hot:.gif"/>';
echo'</br>';
$i=-(-$i-1);
}
echo'</div>';
}
}
echo '</div>';
} 

if(!$user_id){

echo '<div class="phdr" style="text-align:center;">CHÀO MỪNG BẠN ĐẾN VỚI THIÊN ĐƯỜNG GIẢI TRÍ 8vui.Top</div>
<div class="tmn">
<center><b><img src="/images/sv.gif"> Cùng tham gia để có những giây phút giải trí thú vị nhé </b><img src="/images/sv.gif"></center>
<br><img src="/images/sv.gif"><b><font color="green"> 8Vui.Top </font> với nhiều chức năng hấp dẫn:</b>
<br>- Hệ thống forum, chatbox, tin nhắn, kết hôn, kết bạn. Giúp bạn kết nối với thành viên khác dễ dàng
<br>- Hệ thống game mini đa dạng, phong phú: Nông Trại Online, Quay Số, Nâng Cấp, Đấu Boss,...
<br>- Hệ thống đồ họa phong phú, liên tục cập nhật item, vật phẩm mới lạ. Giúp bạn thỏa sức làm đẹp cho nhân vật của mình
<br>
<br>
<b><center>Còn chờ gì nữa. Hãy <a href="dangnhap.html">Đăng Nhập</a> hoặc <a href="/dangki.html">Đăng Kí</a> ngay để cùng trải nghiệm đầy đủ chức năng của mạng xã hội nhé :)</center></b>
</div>';


echo '<div class="phdr">Đăng Nhập Tài Khoản</div>';
echo '<div class="gioithieu" align="center"><form action="/login.php" method="post">
<marquee behavior="scroll" direction="left" scrollamount="1" style="margin-top: 5px"><img src="/icon/iconxoan/dammaynho.png"></marquee><marquee behavior="scroll" direction="left" scrollamount="2" style="margin-top: 10px"><img src="/icon/iconxoan/dammaylon.png"></marquee>
Tài Khoản : 
<br/>
<input
type="text" name="n"
value="" maxlength="28"
size="25" class="name">
<br/>
Mật Khẩu : 
<br/>
<input type="password"
name="p" maxlength="25"
size="25" class="pass">
<br/>
<input
type="hidden" name="mem"
value="1"
checked="checked"><input type="hidden" name="next" value="'.$url.'" />
<font style="font-size="11px"><a href="/quenmatkhau.php" title="Quên mật khẩu">Bạn Quên Mật Khẩu?</a></font><br/>
<input type="submit"  value="&#160;Đăng nhập&#160;" />
<a href="/quenmatkhau.php" id="submit" style="padding:4px 15px" title="Đăng kí làm thành viên" ><b>Đăng kí nhanh</b></a>
</form></div>';

echo '<div class="tmn">
<b> Mạng Xã Hội 8Vui.Top Hỗ Trợ Đa Nền Tảng Điện Thoại. </b>
<br><i class="fa fa-bullhorn"></i> Các Máy Yếu Vẫn Có Thể Chơi Game Mượt Mà Khi Chuyển Sang Giao Diện JaVa 
<br><i class="fa fa-bullhorn"></i> Tuy Nhiên , Các Bạn Dùng SmartPhone Cũng Có Thể Chuyển Sang Giao Diện SmartPhone 
<br><i class="fa fa-bullhorn"></i> Tham Gia vào Mạng xã hội Để Trải Nghiệm Tối Đa Hiệu Ứng Tuyệt Đẹp của Chúng tôi.
</div>';
}

////////

echo'<div class="phdr"><i class="fa fa-bar-chart"></i> Thống kê diễn đàn</div>';
echo'<div class="list1"> • Thành viên : <b><font color="0000ff">' .number_format(mysql_result(mysql_query("SELECT COUNT(*) FROM `users`"), 0)) . '</font></b>
<br/> • Đề tài : <b><font color="0000FF">' .number_format(mysql_result(mysql_query("SELECT COUNT(*) FROM `forum` WHERE `type` = 't' AND `close` != '1'"), 0)) . '</font></b>
<br/> • Bài gửi : <b><font color="0000FF">' .number_format(mysql_result(mysql_query("SELECT COUNT(*) FROM `forum` WHERE `type` = 'm' AND `close` != '1'"), 0)) . '</font></b>
<br/> • Tổng xu : <b><font color="0000FF">' .number_format(mysql_result(mysql_query("SELECT SUM(xu) FROM `users`"), 0)) . '</font></b><br/> • Tổng lượng : <b><font color="0000FF">' .number_format(mysql_result(mysql_query("SELECT SUM(vnd) FROM `users`"), 0)) . '</font></b></div>';

// Thống kê online
$users = mysql_result(mysql_query("SELECT COUNT(*) FROM `users` WHERE `lastdate` > '" . (time() - 300) . "'"), 0);
mysql_query("UPDATE `users` SET $sql `total_on_site` = '$totalonsite', `lastdate` = " . time() . " WHERE `id` = '7'");echo'<div class="phdr"><i class="glyphicon glyphicon-off"></i> Đang có '.($user_id || $set['active'] ? '<a href="/users/index.php?act=online"><font color="f8f8ff">'.$users.'' : $users).'</font></a> thành viên online</div>';
echo'<a id="ok"><div class="omenu"><center><font color="green"><b>[ Xem thành viên đang online ]</b></font></b></center></div></a><div id="oke" style="display: none;">';
echo'<div class="list1">';
include 'incfiles/online.php';
echo '</div>';
echo'</div>';
echo'</div>';
include 'xuli.php';
?>