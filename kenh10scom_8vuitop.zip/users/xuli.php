<script type="text/javascript"> 
$('#click').click(function() {  
$('#show').toggle('fast','linear');  
}); 
$('#vao').click(function() {  
$('#ra').toggle('fast','linear');  
}); 

</script>