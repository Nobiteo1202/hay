<?php
define('_IN_JOHNCMS', 1);
require('../incfiles/core.php');
$textl='Lái buôn';
require('../incfiles/head.php');
if (!$user_id) {
header('Location: /login.php');
exit;
}
echo '<div class="mainblok">';
switch($act) {
default:
echo '<div class="phdr">'.$textl.'</div>';
echo '<table>';
echo '<tr>';
echo '<td>';
echo '<img src="/icon/laibuon.gif">';
echo '</td>';
echo '<td>';
echo '<div class="login"><b><font color="brown"><a href="bangxephang.php"> Bảng xếp hạng</b></font</a></div>';
echo '<div class="login"><b><font color="brown"><a href="?act=baodanh"> Báo danh hằng ngày</b></font</a></div>';
echo '<div class="login"><b><font color="brown"><a href="'.$home.'/farm/nangcap.php"> Nâng cấp đất</b></font</a></div>';
echo '<div class="login"><b><font color="brown"><a href="?act=shuriken"> Đổi Shuriken</b></font</a></div>';
echo '<div class="login"><b><font color="brown"><a href="?act=kunai"> Đổi Kunai</b></font</a></div>';
echo '</td>';
echo '</tr>';
echo '</table>';
break;
case 'baodanh';
echo '<div class="phdr">Báo danh</div>';
if (isset($_POST['baodanh'])) {
if ($datauser['baodanh']==1) {
echo '<div class="rmenu">Hôm nay bạn đã báo danh rồi!</div>';
} else {
mysql_query("UPDATE `vatpham` SET `soluong`=`soluong`+'1' WHERE `user_id`='".$user_id."' AND `id_shop`='12'");
mysql_query("UPDATE `users` SET `chuyencan`=`chuyencan`+'5',`baodanh`='1' WHERE `id`='".$user_id."'");
echo '<div class="menu congdong">Báo danh thành công!</div>';
}
}
echo '<form method="post">';
echo 'Nhận 5 điểm chuyên cần và 1 thẻ quay số free<br/>';
echo '<input type="submit" name="baodanh" value="Báo danh">';
echo '</form>';
break;
case 'shuriken':
$i_3=mysql_fetch_array(mysql_query("SELECT * FROM `fermer_sclad` WHERE `id_user`='".$user_id."' AND `semen`='3'"));
$i_28=mysql_fetch_array(mysql_query("SELECT * FROM `fermer_sclad` WHERE `id_user`='".$user_id."' AND `semen`='28'"));
$i_31=mysql_fetch_array(mysql_query("SELECT * FROM `fermer_sclad` WHERE `id_user`='".$user_id."' AND `semen`='31'"));
echo '<div class="phdr">Đổi Shuriken [<a href="/farm">Nông trại</a>]</div>';
if (isset($_POST['doi'])) {
if ($i_28['kol']>=15&&$i_31['kol']>=15&&$i_3['kol']>=20) {
mysql_query("UPDATE `fermer_sclad` SET `kol`=`kol`-'20' WHERE `semen`='3' AND `id_user`='".$user_id."'");
mysql_query("UPDATE `fermer_sclad` SET `kol`=`kol`-'15' WHERE `semen`='28' AND `id_user`='".$user_id."'");
mysql_query("UPDATE `fermer_sclad` SET `kol`=`kol`-'15' WHERE `semen`='31' AND `id_user`='".$user_id."'");
mysql_query("UPDATE `vatpham` SET `soluong`=`soluong`+'1' WHERE `id_shop`='47' AND `user_id`='".$user_id."'");
echo '<div class="menu">Đổi thành công</div>';
} else {
echo '<div class="rmenu">Không đủ nguyên liệu</div>';
}
}
echo '<form method="post">';
echo '<div class="list1"><b>x15</b><img src="/farm/icon/shop/28.png"><br/>
<b>x20</b><img src="/farm/icon/shop/3.png"><br/>
<b>x15</b><img src="/farm/icon/shop/31.png"><br/>
<br/><input type="submit" name="doi" value="Đổi" style="width:80px; text-align:left; background-position: right;   background-image:url(/images/vatpham/47.png); background-repeat: no-repeat;"></div>';
echo '</form>';
break;
case 'kunai':
$i_3=mysql_fetch_array(mysql_query("SELECT * FROM `fermer_sclad` WHERE `id_user`='".$user_id."' AND `semen`='3'"));
$i_28=mysql_fetch_array(mysql_query("SELECT * FROM `fermer_sclad` WHERE `id_user`='".$user_id."' AND `semen`='28'"));
$i_31=mysql_fetch_array(mysql_query("SELECT * FROM `fermer_sclad` WHERE `id_user`='".$user_id."' AND `semen`='31'"));
echo '<div class="phdr">Đổi Kunai [<a href="/farm">Nông trại</a>]</div>';
if (isset($_POST['doi'])) {
if ($i_28['kol']>=10&&$i_31['kol']>=10&&$i_3['kol']>=15) {
mysql_query("UPDATE `fermer_sclad` SET `kol`=`kol`-'15' WHERE `semen`='3' AND `id_user`='".$user_id."'");
mysql_query("UPDATE `fermer_sclad` SET `kol`=`kol`-'10' WHERE `semen`='28' AND `id_user`='".$user_id."'");
mysql_query("UPDATE `fermer_sclad` SET `kol`=`kol`-'10' WHERE `semen`='31' AND `id_user`='".$user_id."'");
mysql_query("UPDATE `vatpham` SET `soluong`=`soluong`+'1' WHERE `id_shop`='48' AND `user_id`='".$user_id."'");
echo '<div class="menu">Đổi thành công</div>';
} else {
echo '<div class="rmenu">Không đủ nguyên liệu</div>';
}
}
echo '<form method="post">';
echo '<div class="list1"><b>x10</b><img src="/farm/icon/shop/28.png"><br/>
<b>x15</b><img src="/farm/icon/shop/3.png"><br/>
<b>x10</b><img src="/farm/icon/shop/31.png"><br/>
<br/><input type="submit" name="doi" value="Đổi" style="width:80px; text-align:left; background-position: right;   background-image:url(/images/vatpham/48.png); background-repeat: no-repeat;"></div>';
echo '</form>';
break;
//--huy hiệu ánh sáng--//
/*
case 'event':
$i_2=mysql_fetch_array(mysql_query("SELECT * FROM `fermer_sclad` WHERE `id_user`='".$user_id."' AND `semen`='2'"));
$i_28=mysql_fetch_array(mysql_query("SELECT * FROM `fermer_sclad` WHERE `id_user`='".$user_id."' AND `semen`='28'"));
echo '<div class="phdr">Đổi Kem ly [<a href="/farm">Nông trại</a>]</div>';
if (isset($_POST['doi'])) {
if ($i_28['kol']>=10 && $i_2['kol']>=20) {
$time = time() + 30 * 24 * 3600;
mysql_query("UPDATE `fermer_sclad` SET `kol`=`kol`-'20' WHERE `semen`='2' AND `id_user`='".$user_id."'");
mysql_query("UPDATE `fermer_sclad` SET `kol`=`kol`-'10' WHERE `semen`='28' AND `id_user`='".$user_id."'");
mysql_query("UPDATE `vatpham` SET `soluong`=`soluong`+'1', `timesudung` = '".$time."' WHERE `id_shop`='46' AND `user_id`='".$user_id."'");
echo '<div class="menu">Đổi thành công</div>';
} else {
echo '<div class="rmenu">Không đủ nguyên liệu</div>';
}
}
echo '<form method="post">';
echo '<div class="list1"><b>x10</b><img src="/farm/icon/shop/28.png"><br/>
<b>x20</b><img src="/farm/icon/shop/2.png"><br/>
<br/><input type="submit" name="doi" value="Đổi" style="width:80px;height:60px;text-align:left; background-position: right;background-image:url(http://i.imgur.com/vCGprNG.png); background-repeat: no-repeat;"></div>';
echo '</form>';
break;

}
*/
}
echo '</div>';
require('../incfiles/end.php');
?>
                            
                            
                            
                            