<?php
define('_IN_JOHNCMS', 1);
require('incfiles/core.php');
require('incfiles/head.php');

echo '<div class="phdr"> Quên mật khẩu </div>';
echo'<div class="list1"></br> Nếu quên mật khẩu</br>Soạn Tin Nhắn :<b> ON 8VUI PASS </b>gửi <b>8085</b></br>Lưu ý : dùng số điện thoại đã kích hoạt tài khoản của bạn </div>';
echo'<div class="list1">Nếu quên mật khẩu cấp 2 </br>Soạn Tin Nhắn :<b> ON 8VUI PASS2 </b>gửi <b>8085</b></br>Lưu ý : dùng số điện thoại kích hoạt của tài khoản của bạn </b> </div>';

require('incfiles/end.php');
?>