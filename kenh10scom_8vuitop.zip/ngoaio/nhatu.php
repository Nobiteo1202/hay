<?php
define('_IN_JOHNCMS', 1);
require ('../incfiles/core.php');
if (!$user_id) {
header('Location: /login.php');
exit;
}
$textl = 'Nhà Tù';
require ('../incfiles/head.php');

echo'<div class="main-xmenu">';
if ($ban)
{
echo'<div class="danhmuc">Vi phạm của bạn</div>';
$vipham = mysql_fetch_array(mysql_query("SELECT * FROM `cms_ban_users` WHERE `user_id`='" . $user_id. "' ORDER BY `ban_while` DESC LIMIT 1"));
echo'<div class="list1">Đăng nhập không thành công !<br/>• Bạn bị khóa bởi : <b>'.$vipham['ban_who'].'</b><br/>• lý do bị khóa : '.$vipham['ban_reason'].'<br/>• Thời gian : '.thoigiantinh($vipham['ban_time']).'<br/>• Liên hệ Admin để biết thêm chi tiết<br/><center><a href="/exit.php">Trở lại đăng nhập</a></center></div>';
}
echo '<div class="danhmuc">Nhà tù</div>';
echo'<div class="viengame">';
echo'<div class="tuongnhatu"><div class="cuasonhatu"></div></div>';
echo '<div class="nennhatu" style="text-align: center;">';
mysql_query("UPDATE `vitri` SET `online`='nhatu' WHERE `user_id`='".$user_id."'");
$req=mysql_query("SELECT * FROM `cms_ban_users` WHERE `ban_time`>'".time()."' ORDER BY RAND() LIMIT 15");
while ($res = mysql_fetch_array($req)) {
$name=mysql_fetch_array(mysql_query("SELECT * FROM `users` WHERE `id`='".$res[user_id]."'"));
 echo '<a href="/member/'.$res['user_id'].'.html"><label style="display: inline-block;text-align: center;"><s><b style="font-size: 9px;color:black;font-weight:bold;text-align: center;">'.$name[name].'</b></s><br><img src="/avatar/'.$res[user_id].'.png"></label></a>';
}
echo'</div>';
echo'</div>';
echo'</div>';
echo '<div class="main-xmenu">';
if(isset($_POST['submitchat'])) {
$loai=functions::checkout($_POST['loai']);
$noidungchat = bbcode::notags($noidungchat);
$noidungchat = isset($_POST['noidungchat']) ? functions::checkin(trim($_POST['noidungchat'])) : '';
if(empty($_POST['noidungchat'])) {
echo '<div class="menu">Bạn đã nhập nội dung đâu</div>';
} else if(strlen($_POST['noidungchat']) < 2) { // 2 là số kí tự ít nhất
echo '<div class="menu">Bạn phải viết trên 5 kí tự</div>';
} else if(strlen($_POST['noidungchat']) > 4000) {
echo '<div class="menu">Bạn không được viết quá 5000 kí tự</div>';
} else {
if($user_id){
$checknv=mysql_num_rows(mysql_query("SELECT * FROM `nhiemvu_user` WHERE `user_id`='".$user_id."' AND `id_nv`='3'"));
if ($checknv>0) {
mysql_query("UPDATE `nhiemvu_user` SET `tiendo`=`tiendo`+'1' WHERE `user_id`='".$user_id."' AND `id_nv`='3'");
}
mysql_query("INSERT INTO `guest` SET `user_id`='".$user_id."', `text`='" . mysql_real_escape_string($noidungchat) . "', `time`='".time()."'");
header('Location: '.$home.'/sanbay/nhatu.php');
}
}
}
if($user_id){
if ($datauser['chanchat'] == 1)
{
echo '<div class="rmenu">Bạn đã bị chặn chat...</div>';
}
else
{
echo '<div class="list1"><form name="text" method="POST">'.bbcode::auto_bb('shoutbox', 'msg').'<div class="list1"><textarea style="border-left:2px solid #44B6AE !important;"  placeholder="Vui lòng viết tiếng việt có dấu để tôn trọng người đọc" id="postText" name="noidungchat" class="form-control"></textarea><input type="hidden" name="ref" value="'.$refer.'"/><input type="hidden" name="token" value="'.$token.'"><br /><button name="submitchat" type="submit"><i class="fa fa-pencil" aria-hidden="true"></i> ' . $lng['sent'] . '</button></form></div>';
/*echo '<table cellpadding="0" cellspacing="0" width="100%" border="0" style="table-layout:fixed;word-wrap: break-word;">
<tbody><tr><td width="60px;" class="blog-avatar"><img src="/avatar/'.$user_id.'.png"  align="top">&nbsp;</td><td style="vertical-align: bottom;"><table cellpadding="0" cellspacing="0">
<tbody><tr><td class="current-blog" rowspan="2" style="">
<div class="blog-bg-left"><img src="/giaodien/images/left-blog.png"></div><div class="newsx">
<form name="text" method="POST">
<textarea type="text" placeholder="Chém vui vẻ!" id="postText" name="noidungchat" class="form-control"></textarea>
<button name="submitchat" type="submit" id="submit" class="nut">Gửi</button>
</form>
</div></td></tr></tbody></table></td></tr></tbody></table>';*/
}
}
$tong = mysql_result(mysql_query("SELECT COUNT(*) FROM `guest`"), 0);
if($tong) {
$req = mysql_query("SELECT * FROM `guest` ORDER BY `time` DESC LIMIT $start, $kmess");
while ($vina4u = mysql_fetch_assoc($req)) {
$gres = mysql_fetch_array(mysql_query("SELECT * FROM `users` WHERE `id`='{$vina4u['user_id']}'"));
echo'<div class="forumtext">';
echo'<table cellpadding="0" cellspacing="0" width="100%" border="0" style="table-layout:fixed;word-wrap: break-word;">
<tr><td width="60px;" class="blog-avatar">';
echo '<img class="avatarforum" src="../avatar/'.$gres['id'].'.png" width="45" height="48" alt="'.$gres['name'].'"/>';
echo'</td><td style="vertical-align: bottom;"><table cellpadding="0" cellspacing="0"><tbody>
<tr><td class="current-blog" rowspan="2" style=""><div class="blog-bg-left">';
echo'<img src="/giaodien/images/left-blog.png"></div>';
echo (time() > $gres['lastdate'] + 300 ? ' <img style="vertical-align:middle;" title="' . $res['from'] . ' is offline" src="/images/off.png" alt="offline"/> ' : '<img style="vertical-align:middle;" title="' . $res['from'] . ' is online" src="/images/on.png" alt="online"/> ');
echo'<a href="/member/'.$gres['id'].'.html"><b><font color="003366">'.nick($gres['id']).'</font></b></a>';
echo'<div class="text">';
$post = functions::checkout($vina4u['text'], 1, 1);
if ($set_user['smileys'])
$post = functions::smileys($post, $vina4u['rights'] ? 1 : 0);
echo''.$post.'<br/><br/>';
echo '<span style="font-size:11px;color:#777;"> (' . functions::thoigian($vina4u['time']) . ')</span>';
echo'</div></div></td></tr></tbody></table></td></tr></tbody></table>';
echo'</div>';
$i++;
}
} else {
echo '<div class="menu list-bottom">Chưa có ai chát !</div>';
}
if ($tong > $kmess) {
echo '<div class="topmenu">' . functions::pages('/sanbay/nhatu.php?page=', $start, $tong, $kmess) . '</div>';
}
echo '</div>';
require ('../incfiles/end.php');
?>