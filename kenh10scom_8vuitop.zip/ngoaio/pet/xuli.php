<script type="text/javascript"> 
$('#1').click(function() {  
$('#1s').toggle('fast','linear');  
}); 
$('#2').click(function() {  
$('#2s').toggle('fast','linear');  
}); 
$('#3').click(function() {  
$('#3s').toggle('fast','linear');  
}); 
$('#4').click(function() {  
$('#4s').toggle('fast','linear');  
}); 
$('#5').click(function() {  
$('#5s').toggle('fast','linear');  
}); 
$('#6').click(function() {  
$('#6s').toggle('fast','linear');  
}); 
$('#7').click(function() {  
$('#7s').toggle('fast','linear');  
});
$('#ccc').click(function() {  
$('#cccs').toggle('fast','linear');  
});
</script>