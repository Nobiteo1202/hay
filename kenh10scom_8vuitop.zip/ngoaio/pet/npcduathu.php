<?php
define('_IN_JOHNCMS', 1);
require('../../incfiles/core.php');
$textl='Đua Pet';
require('../../incfiles/head.php');
if (!$user_id) {
header('Location: /login.php');
exit;
}
echo '<div class="mainblok">';
switch($act) {
default:
echo '<div class="phdr">'.$textl.'</div>';
echo '<table>';
echo '<tr>';
echo '<td>';
echo '<img src="/icon/duathu.gif">';
echo '</td>';
echo '<td>';
echo '<div class="login"><b><font color="brown"><a href="duathu.php"> Đặt cược</b></font</a></div>';
echo '<div class="login"><b><font color="brown"><a href="?act=huongdan"> Hướng dẫn đua pet</b></font</a></div>';
echo '</td>';
echo '</tr>';
echo '</table>';
break;
case 'huongdan';
echo '<div class="phdr">Hướng dẫn đua pet</div>';
echo '<b>Bước 1 :</b> đặt cược vào con pet mà bạn muốn , và tối thiểu đặt cược là 2.000.000xu , thắng sẽ được x3 tiền đặt cược  </br> <b>Bước 2 : </b> Chờ đợi kết quả ';
break;
}
echo '</div>';
require('../../incfiles/end.php');
?>