<?php
define('_IN_JOHNCMS', 1);
require('../incfiles/core.php');
$textl = 'Khu ngoại ô';
require('../incfiles/head.php');
echo'<div class="main-xmenu">';
echo'<div class="phdr"><center>Khu ngoại ô</center></div>';
date_default_timezone_set('Asia/Ho_Chi_Minh');
if (!$user_id){
echo'<div class="menu">Bạn phải đăng nhập để chơi game này nhé !</div>';
echo'</div>';
require('../incfiles/end.php');
exit;
}
echo'<style type="text/css"> 
.ngoaio{background:url("http://i.imgur.com/3Ai56v9.gif") no-repeat; background-size: 900px 256px;} 
</style>';
echo '<div class="menu"><div class="ngoaio" style="min-height:256px"><marquee behavior="scroll" direction="left" scrollamount="1" style="margin-top: 5px"><img src="/icon/iconxoan/dammaynho.png"></marquee><marquee behavior="scroll" direction="left" scrollamount="2" style="margin-top: 10px"><img src="/icon/iconxoan/dammaylon.png"></marquee></div><div class="cola" style="min-height: 100px;margin:0"><div class="buico"></div><a href="nhatu.php"><img src="/icon/giamthi.gif"></a><a href="nhatu.php"><img src="/icon/nhatu.png"></a><img src="/icon/cay.png" style="float:right"><center>';
echo'</br></br></br></br><a href="pet/npcduathu.php"><img src="/icon/duathu.gif" style="margin-top: -120px;"></a><a href="pet/duathu.php"><img src="/icon/duathu.png" style="margin-top: -120px;"></a>'; 
echo'<br/>';
//--code này copy để hiện avatar by cRoSsOver--//
//update nơi đang online và tọa độ
mysql_query("UPDATE `vitri` SET `time`='".time()."',`online`='".$textl."',`toado`='".$toado."' WHERE `user_id`='".$user_id."'");
$time=time()-300;
//bắt đầu cho hiện avatar
$req=mysql_query("SELECT * FROM `vitri` WHERE `online`='".$textl."' AND `time`>'".$time."'");
while($pr = mysql_fetch_array($req))
    {
$name=mysql_fetch_array(mysql_query("SELECT * FROM `users` WHERE `id`='".$pr[user_id]."'"));
$flip=rand(1,2);
if($flip==1) {$flip=' class="flip"';}
else {$flip='';}
        echo '<a href="/member/'.$pr['user_id'].'.html"><label style="display: inline-block;text-align: center;"><b style="font-size: 9px;color:red;font-weight:bold;text-align: center;">'.$name[name].'</b><br><img src="/avatar/'.$pr[user_id].'.png"></label></a>';
    }
echo'</center><div class="buico"></div></div>';
echo'</div></div>';
require('../incfiles/end.php');
?>