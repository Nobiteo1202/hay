<?php
define('_IN_JOHNCMS', 1);
require('../incfiles/core.php');
$textl = 'Khu Công Viên';
require('../incfiles/head.php');
echo'<div class="main-xmenu">';
echo'<div class="phdr"><center>Khu Công Viên</center></div>';
if (empty($datauser['mibile'])) {
	if(isset($_POST['active_sub'])) {
		$code = intval($_POST['active']);
		$check_code = mysql_num_rows(mysql_query("SELECT * FROM `kichhoat` WHERE `code` = '".$code."' AND `user_id` = '".$user_id."' AND `time` >= '".time()."'"));
		if ($check_code < 1) {
			echo '<div class="rmenu">Mã kích hoạt không tồn tại hoặc hết hạn sử dụng!</div>';
		} else {
			$info_code = mysql_fetch_assoc(mysql_query("SELECT * FROM `kichhoat` WHERE `code` = '".$code."'"));
			mysql_query("UPDATE `users` SET `mibile` = '".$info_code['sdt']."', `xu` = `xu` + '5000000', `vnd`= `vnd` + '5' WHERE `id` ='".$user_id."'");
			echo '<div class="list1">Kích hoạt tài khoản thành công. Bạn được cộng <b>5,000,000 xu</b> và <b>5 lượng</b></div>';
		}
	}
	echo '<form method="post"><div class="list1">Vui lòng kích hoạt tài khoản để nhắn tin ( chỉ có 500đ ) </br> Soạn : <b>ON 8VUI ACTIVE '.$user_id.'</b> gửi <b>8085</b></br> sau đó làm theo hướng dẫn khi tin nhắn gửi về </br> kích hoạt xong nhận được 5,000,000 xu và 5 lượng</div>
	<div class="omenu"><center><input type="text" name="active" placeholder="Nhập mã kích hoạt..."> <input type="submit" name="active_sub" value="Kích hoạt"></center>
	</form></div>';
}
date_default_timezone_set('Asia/Ho_Chi_Minh');
if (!$user_id){
echo'<div class="menu">Bạn phải đăng nhập để chơi game này nhé !</div>';
echo'</div>';
require('../incfiles/end.php');
exit;
}
echo '<div class="menu"><div class="nencay" style="min-height:140px"><marquee behavior="scroll" direction="left" scrollamount="1" style="margin-top: 5px"><img src="/icon/iconxoan/dammaynho.png"></marquee><marquee behavior="scroll" direction="left" scrollamount="2" style="margin-top: 10px"><img src="/icon/iconxoan/dammaylon.png"></marquee></div><div class="cola" style="min-height: 100px;margin:0"><div class="buico"></div><a href="/congvien/bxh.php"><img src="/icon/bxh.png"></a><a href="nhiemvu.php"><img src="/icon/npcnhiemvu.gif"></a><img src="/icon/cay.png"><a href="daugia.php"><img src="/icon/daugia2.png" style="float:right"></a><a href="daugia.php"><img src="/icon/daugia.gif" style="float:right"></a><center>';
echo'<a href="quayso.php"><img src="/icon/quayso.gif" style="margin-top: -120px;margin-bottom: -120px;"><img src="/icon/quayso.png" style="margin-top: -120px;margin-bottom: -120px;"></a>'; 
echo'<a href="code.php"><img src="/icon/gc.gif"></a>';
echo'<br/>';
//--code này copy để hiện avatar by cRoSsOver--//
//update nơi đang online và tọa độ
mysql_query("UPDATE `vitri` SET `time`='".time()."',`online`='".$textl."',`toado`='".$toado."' WHERE `user_id`='".$user_id."'");
$time=time()-300;
//bắt đầu cho hiện avatar
$req=mysql_query("SELECT * FROM `vitri` WHERE `online`='".$textl."' AND `time`>'".$time."'");
while($pr = mysql_fetch_array($req))
    {
$name=mysql_fetch_array(mysql_query("SELECT * FROM `users` WHERE `id`='".$pr[user_id]."'"));
$flip=rand(1,2);
if($flip==1) {$flip=' class="flip"';}
else {$flip='';}
        echo '<a href="/member/'.$pr['user_id'].'.html"><label style="display: inline-block;text-align: center;"><b style="font-size: 9px;color:red;font-weight:bold;text-align: center;">'.$name[name].'</b><br><img src="/avatar/'.$pr[user_id].'.png"></label></a>';
    }
echo'</center><div class="buico"></div></div>';
echo'</div>';
if(isset($_GET['dondep'])){
if ($rights >= 6) {
if(isset($_POST['submit'])) {
header("Location: $home");
mysql_query("DELETE FROM `guest`");
} else {
echo '<div class="menu list-bottom congdong"><form method="post">Bạn có muốn dọn dẹp phòng chát không !<br /><input type="submit" name="submit" value="Dọn dẹp" /></form></div>'; 
}
} else {
header("Location: $home/congvien/");
}
}
if(isset($_POST['submitchat'])) {
$loai=functions::checkout($_POST['loai']);
$noidungchat = bbcode::notags($noidungchat);
$noidungchat = isset($_POST['noidungchat']) ? functions::checkin(trim($_POST['noidungchat'])) : '';
if(empty($_POST['noidungchat'])) {
echo '<div class="menu">Bạn đã nhập nội dung đâu</div>';
} else if(strlen($_POST['noidungchat']) < 2) { // 2 là số kí tự ít nhất
echo '<div class="menu">Bạn phải viết trên 5 kí tự</div>';
} else if(strlen($_POST['noidungchat']) > 4000) {
echo '<div class="menu">Bạn không được viết quá 5000 kí tự</div>';
} else {
if($user_id){
$checknv=mysql_num_rows(mysql_query("SELECT * FROM `nhiemvu_user` WHERE `user_id`='".$user_id."' AND `id_nv`='3'"));
if ($checknv>0) {
mysql_query("UPDATE `nhiemvu_user` SET `tiendo`=`tiendo`+'1' WHERE `user_id`='".$user_id."' AND `id_nv`='3'");
}
mysql_query("INSERT INTO `guest` SET `user_id`='".$user_id."', `text`='" . mysql_real_escape_string($noidungchat) . "', `time`='".time()."'");
header('Location: '.$home.'/congvien/');
}
}
}
if($user_id){
if ($datauser['chanchat'] == 1)
{
echo '<div class="rmenu">Bạn đã bị chặn chat...</div>';
}
else
{
echo '<div class="list1"><form name="text" method="POST">'.bbcode::auto_bb('shoutbox', 'msg').'<div class="list1"><textarea style="border-left:2px solid #44B6AE !important;"  placeholder="Vui lòng viết tiếng việt có dấu để tôn trọng người đọc" id="postText" name="noidungchat" class="form-control"></textarea><input type="hidden" name="ref" value="'.$refer.'"/><input type="hidden" name="token" value="'.$token.'"><br /><button name="submitchat" type="submit"><i class="fa fa-pencil" aria-hidden="true"></i> ' . $lng['sent'] . '</button></form></div>';
/*echo '<table cellpadding="0" cellspacing="0" width="100%" border="0" style="table-layout:fixed;word-wrap: break-word;">
<tbody><tr><td width="60px;" class="blog-avatar"><img src="/avatar/'.$user_id.'.png"  align="top">&nbsp;</td><td style="vertical-align: bottom;"><table cellpadding="0" cellspacing="0">
<tbody><tr><td class="current-blog" rowspan="2" style="">
<div class="blog-bg-left"><img src="/giaodien/images/left-blog.png"></div><div class="newsx">
<form name="text" method="POST">
<textarea type="text" placeholder="Chém vui vẻ!" id="postText" name="noidungchat" class="form-control"></textarea>
<button name="submitchat" type="submit" ><i class="fa fa-pencil" aria-hidden="true"></i> Gửi</button>
</form>
</div></td></tr></tbody></table></td></tr></tbody></table>';*/
}
} else {
}
$tong = mysql_result(mysql_query("SELECT COUNT(*) FROM `guest`"), 0);
if($tong) {
$req = mysql_query("SELECT * FROM `guest` ORDER BY `time` DESC LIMIT $start, $kmess");
while ($vina4u = mysql_fetch_assoc($req)) {
$gres = mysql_fetch_array(mysql_query("SELECT * FROM `users` WHERE `id`='{$vina4u['user_id']}'"));
echo'<div class="forumtext">';
echo'<table cellpadding="0" cellspacing="0" width="100%" border="0" style="table-layout:fixed;word-wrap: break-word;">
<tr><td width="60px;" class="blog-avatar">';
echo '<img class="avatarforum" src="../avatar/'.$gres['id'].'.png" width="45" height="48" alt="'.$gres['name'].'"/>';
echo'</td><td style="vertical-align: bottom;"><table cellpadding="0" cellspacing="0"><tbody>
<tr><td class="current-blog" rowspan="2" style=""><div class="blog-bg-left">';
echo'<img src="/giaodien/images/left-blog.png"></div>';
echo (time() > $gres['lastdate'] + 300 ? ' <img style="vertical-align:middle;" title="' . $res['from'] . ' is offline" src="/images/off.png" alt="offline"/> ' : '<img style="vertical-align:middle;" title="' . $res['from'] . ' is online" src="/images/on.png" alt="online"/> ');
echo'<a href="/member/'.$gres['id'].'.html"><b><font color="003366">'.nick($gres['id']).'</font></b></a>';
echo'<div class="text">';
$post = functions::checkout($vina4u['text'], 1, 1);
if ($set_user['smileys'])
$post = functions::smileys($post, $vina4u['rights'] ? 1 : 0);
echo''.$post.'<br/><br/>';
echo '<span style="font-size:11px;color:#777;"> (' . functions::thoigian($vina4u['time']) . ')</span>';
echo'</div></div></td></tr></tbody></table></td></tr></tbody></table>';
echo'</div>';
$i++;
}
} else {
echo '<div class="menu list-bottom">Chưa có ai chát !</div>';
}
if ($tong > $kmess) {
echo '<div class="topmenu">' . functions::pages('/congvien/?page=', $start, $tong, $kmess) . '</div>';
}
echo'</div>';
require('../incfiles/end.php');
?>