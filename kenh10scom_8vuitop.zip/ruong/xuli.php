<script type="text/javascript">
$('#s').click(function() {  
$('#ss').toggle('fast','linear');  
}); 
$('#sss').click(function() {  
$('#ssss').toggle('fast','linear');  
}); 
</script>