<?php
$config = array(
    'ws_url' => 'http://gachthe.megapay.net.vn/chargingApi',                                         //link webservice của Epay
    'partnerId' => '10855',                                                                     //Mã Merchant, sau khi đăng ký dịch vụ, Epay sẽ cung cấp cho khách hàng
    'targetAcc' => '0932660146',                                                                    //Tên Merchant Epay cung cấp cho khách hàng
    'password' => '9f5d21'
);
?>