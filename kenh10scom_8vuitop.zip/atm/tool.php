<?php
define('_IN_JOHNCMS',1);
require('../incfiles/core.php');
$textl='Tools admin';
require('../incfiles/head.php');
if (!$user_id||$rights!=9) {
header('Location: /login.php');
exit;
}
echo '<div class="mainblok">';
echo '<div class="phdr">Edit nạp VNĐ</div>';
if (isset($_GET[thanhcong_vnd])) {
echo '<div class="news">Edit thành công!</div>';
}
$rvnd=mysql_query("SELECT * FROM `napthe` WHERE `loai`='vnd'");
if (isset($_POST[submit])) {
@mysql_query("UPDATE `napthe` SET `tien`='".$_POST[vnd]."' WHERE `id`='".$_POST[idvnd]."'");
header('Location: ?thanhcong_vnd');
}
while($pvnd=mysql_fetch_array($rvnd)) {
echo '<form method="post"><input type="hidden" name="idvnd" value="'.$pvnd[id].'"><div class="list1">Mệnh giá: <b>'.$pvnd[menhgia].'</b> => <input type="text" name="vnd" value="'.$pvnd[tien].'" size="4"> VNĐ <input type="submit" name="submit" value="OK"></div></form>';
}
echo '<div class="phdr">Edit nạp XU</div>';
if (isset($_GET[thanhcong_xu])) {
echo '<div class="news">Edit thành công!</div>';
}
$rxu=mysql_query("SELECT * FROM `napthe` WHERE `loai`='xu'");
if (isset($_POST[submit])) {
@mysql_query("UPDATE `napthe` SET `tien`='".$_POST[xu]."' WHERE `id`='".$_POST[idxu]."'");
header('Location: ?thanhcong_xu');
}
while($pxu=mysql_fetch_array($rxu)) {
echo '<form method="post"><input type="hidden" name="idxu" value="'.$pxu[id].'"><div class="list1">Mệnh giá: <b>'.$pxu[menhgia].'</b> => <input type="text" name="xu" value="'.$pxu[tien].'" size="4"> Xu <input type="submit" name="submit" value="OK"></div></form>';
}
echo '</div>';
require('../incfiles/end.php');
?>