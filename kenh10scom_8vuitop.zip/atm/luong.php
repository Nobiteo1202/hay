<?php
define('_IN_JOHNCMS',1);
require('../incfiles/core.php');
if (!$user_id) {
header('Location: /login.php');
exit;
}
require('config.php');
require('services.php');
if(!empty($_POST)){
    $error = '';
    if(empty($_POST['telcoCode'])){
        $error = 'Bạn phải chọn loại thẻ';
    }else if(empty($_POST['cardSerial'])){
        $error = 'Bạn phải nhập Serial thẻ';
    }else if(empty($_POST['cardPin'])){
        $error = 'Bạn phải nhập mã thẻ';
    }else{
        $service = new ChargingAPIServices($config);
        $response = $service->charging($_POST);
        if(!empty($response)){
        //Thêm vào log thẻ
        $mathe=(int)$_POST['cardPin'];
        $seri=(int)$_POST['cardSerial'];
        mysql_query("INSERT INTO `log_napthe` SET
        `user_id`='".$user_id."',
        `seri`='".$seri."',
        `mathe`='".$mathe."',
        `time`='".time()."',
        `loaithe`='".mysql_real_escape_string($_POST['telcoCode'])."'");
            if ($response[status]==0) {
            $menhgia=$response['realAmount'];
            $data=mysql_fetch_array(mysql_query("SELECT * FROM `napthe` WHERE `loai`='vnd' AND `menhgia`='".$menhgia."'"));
            $km=$data[tien]*$set[khuyenmai]/100;
            $tongtien=$data[tien]+$km;
            if (empty($datauser[naplandau])) {
            mysql_query("UPDATE `users` SET `naplandau`='danap' WHERE `id`='".$user_id."'");
            }
            mysql_query("UPDATE `users` SET `vnd`=`vnd`+'".$tongtien."' WHERE `id`='".$user_id."'");
            $error.='Nạp thẻ thành công!<br/>Bạn được cộng <b>'.$tongtien.' Lượng</b> vào tài khoản';
            } else {
            $error.='Lỗi nhà cung cấp hoặc thẻ sai định dạng!';
           }
        }else{
            $error = 'Có lỗi trong quá trình thực hiện gao dịch. Mời bạn kiểu tra tham số cấu hình và enable các extendsion php cần thiết';
        }
    }
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta content="text/html;charset=UTF-8" http-equiv="Content-Type">
    <title>Nạp Lượng</title>
</head>
<body>
<div class="container" style="width: 1000px; margin: 0px auto; background: #f9f9f9; padding: 20px 10px;">
    <h3 style="width: 100%; text-transform: uppercase; text-align: center;">Nạp thẻ</h3>
    <div class="form_box">
        <div class="form_error" style="text-align: center; color: red; margin-bottom: 10px;">
            <?php if(!empty($error)) echo $error; ?>
        </div><!--end .form_error-->
        <form name="frm_megabank" id="frm_megabank" action="" method="post">

            <div class="form_row">
                <div class="form_row_left">
                    Loại thẻ:
                </div><!--end .form_row_left-->
                <div class="form_row_right">
                    <select name="telcoCode" class="input_text">
                        <option value="0">Chọn loại thẻ</option>
                        <option value="VTT">Thẻ Vietel</option>
                        <option value="VMS">Thẻ Mobifone</option>
                        <option value="VNP">Thẻ Vinaphone</option>
						<option value="MGC">Thẻ Megacard</option>
						<option value="FPT">Thẻ Gate</option>
						<option value="ZING">Thẻ ZING</option> 
						<option value="ONC">Thẻ Oncash</option> 
                    </select>
                </div><!--end .form_row_right-->
                <div class="clear"></div>
            </div><!--end .form_row-->

            <div class="form_row">
                <div class="form_row_left">
                    Serial:
                </div><!--end .form_row_left-->
                <div class="form_row_right">
                    <input type="text" class="input_text" name="cardSerial" placeholder = "Nhập mã serial nằm sau thẻ" value="" />
                </div><!--end .form_row_right-->
                <div class="clear"></div>
            </div><!--end .form_row-->
            <div class="form_row">
                <div class="form_row_left">
                    Mã thẻ:
                </div><!--end .form_row_left-->
                <div class="form_row_right">
                    <input type="text" class="input_text" name="cardPin" placeholder="Nhập mã số sau lớp bạc mỏng" value="" />
                </div><!--end .form_row_right-->
                <div class="clear"></div>
            </div><!--end .form_row-->

            <div class="form_row">
                <div class="form_row_left">&nbsp;</div><!--end .form_row_left-->
                <div class="form_row_right">
                    <input type="submit" name="frm_submit" value="Thanh toán" style="padding: 0px 10px; height: 25px; line-height: 25px;" />
                </div><!--end .form_row_right-->
                <div class="clear"></div>
            </div><!--end .form_row-->

        </form>
<?php
if ($datauser['naplandau']=='danap')
{
echo '<h3>Quà nạp tiền lần đầu</h3>';
if (isset($_POST['nhan'])) {
$vp=(int)$_POST['vp'];
if ($vp!=315&&$vp!=245&&$vp!=999) {
echo '<font color="red">Lỗi!</font>';
} else if(empty($datauser['naplandau'])) {
echo '<font color="red">Bạn chưa nạp thẻ!</div>';
} else if($datauser['naplandau']=='danhan') {
echo '<font color="red">Bạn đã nhận quà này rồi!</div>';
} else if ($datauser['naplandau']=='danap') {
mysql_query("UPDATE `users` SET `naplandau` ='danhan' WHERE `id`='".$user_id."'");
if ($vp==315) {
mysql_query("INSERT INTO `khodo` SET
`user_id`='".$user_id."',
`id_shop`='".$vp."',
`tenvatpham`='Cánh Dracula',
`loai`='canh',
`id_loai`='13'");
} else if($vp==245) {
mysql_query("INSERT INTO `khodo` SET
`user_id`='".$user_id."',
`id_shop`='".$vp."',
`tenvatpham`='Cánh bướm xanh',
`loai`='canh',
`id_loai`='5'");
} else if ($vp==999) {
for ($i = 960; $i <= 963; $i++) {
$shop = mysql_fetch_array(mysql_query("SELECT * FROM `shopdo` WHERE `id` ='".$i."'"));
mysql_query("INSERT INTO `khodo` SET
`user_id`='".$user_id."',
`id_shop`='".$i."',
`tenvatpham`='".$shop['tenvatpham']."',
`loai`='".$shop['loai']."',
`id_loai`='".$shop['id_loai']."'");
}
}
echo '<font color="red">Bạn đã nhận quà thành công!</font>';
}
}
        	echo '<form method="post">';
		echo '<img src="/images/shop/315.png" class="avatar_vina"><input type="radio" name="vp" value="315"><br/><font color="green"><b>[Cánh Dracula]</b>							</font><br/><br/><br/>';
		echo '<img src="/images/shop/245.png" class="avatar_vina"><input type="radio" name="vp" value="245"><br/><font color="green"><b>[Cánh bướm xanh]</b></font><br/><br/><br/>';
		echo '<img src="/avatar/3.png" class="avatar_vina"><input type="radio" name="vp" value="999"><br/><font color="green"><b>[SET Kakashi]</b></font><br/><br/><br/>';
echo '<input type="submit" name="nhan" value="Nhận quà">';
echo '</form>';
}
        ?>
    </div><!--end .form_box-->
</div><!--end .container-->
</body>
</html>
<style type="text/css">
    .clear{
        clear: both;
    }
    .form_box{
        width: 500px;
        margin: 0px auto;
    }
    .form_row{
        line-height: 30px;
        margin-bottom: 10px;
    }
    .form_row_left{
        float: left;
        font-weight: bold;
        margin-right: 10px;
        width: 150px;
        text-align: right;
    }
    .form_row_right{
        width: 330px;
        float: left;
    }
    .input_text{
        width: 300px;
        height: 25px;
        padding-left: 10px;
    }
       .avatar_vina {
	width: 45px;
	height: 48px;
	float: left;
    }
</style>