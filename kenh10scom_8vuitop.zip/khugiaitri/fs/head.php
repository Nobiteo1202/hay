<?php
echo '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="revisit-after"content="1 days"/><meta name="googlebot"content="index, follow"/><meta name="robots"content="index, follow"/><meta name="rating"content="general"/>';
echo '

<link rel="stylesheet" type="text/css" href="http://mchoi.mobi/fs/style.css" media="handheld,all">
<title>FS Online - 8vui.top</title></head>';
echo '<div  style="padding-top:5px;padding-bottom:5px;" class="header"><font color="red" size="5"><a href="/">8vui.Top</a></font><br/>
Cộng Đồng Giải Trí Trên MoBi</div>';
echo '<div class="menu"><center><a href="../">Trang chủ</a> • <a href="http://8vui.top">Diễn Đàn</a></div> ';
echo '<div class="body">';
?>
