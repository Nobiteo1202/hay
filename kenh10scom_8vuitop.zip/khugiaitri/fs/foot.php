<?php
echo '</div>';
echo '<div class="footer"><center><b>Bản quyền 2016 &reg; <a href="http://8vui.Top">8VUI.Top</a></b></center></div>
';
?>
