<?php
define('_IN_JOHNCMS',1);
require('../incfiles/core.php');
$textl='Đập trứng';
require('../incfiles/head.php');
echo '<div class="mainblok">';
echo '<div class="phdr">'.$textl.'</div>';
?>
<center><a href="#"><img src="/khugiaitri/img/daptrung/trungdo.jpg" onmouseover="this.src='/khugiaitri/img/daptrung/trungdos.png'" onmouseout="this.src='/khugiaitri/img/daptrung/trungdo.jpg'"></a>
<a href="#"><img src="/khugiaitri/img/daptrung/trungtim.jpg" onmouseover="this.src='/khugiaitri/img/daptrung/trungtims.png'" onmouseout="this.src='/khugiaitri/img/daptrung/trungtim.jpg'"></a>
<a href="#"><img src="/khugiaitri/img/daptrung/trungvang.jpg" onmouseover="this.src='/khugiaitri/img/daptrung/trungvangs.png'" onmouseout="this.src='/khugiaitri/img/daptrung/trungvang.jpg'"></a>
<a href="#"><img src="/khugiaitri/img/daptrung/trungxanh.jpg" onmouseover="this.src='/khugiaitri/img/daptrung/trungxanhs.png'" onmouseout="this.src='/khugiaitri/img/daptrung/trungxanh.jpg'"></a>
<a href="#"><img src="/khugiaitri/img/daptrung/trungxanhbien.jpg" onmouseover="this.src='/khugiaitri/img/daptrung/trungxanhbiens.png'" onmouseout="this.src='/khugiaitri/img/daptrung/trungxanhbien.jpg'"></a></center>
<?php
echo '</div>';
require('../incfiles/end.php');
?>