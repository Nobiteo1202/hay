<?php
define('_IN_JOHNCMS', 1);
$textl = 'Khu câu cá';
require_once ('../../incfiles/core.php');
require_once ('../../incfiles/head.php');
echo '<div class="phdr"> Anh Ba Khía </div>';
echo '<div class="forumtext">
<table cellpadding="0" cellspacing="0" width="99%" border="0" style="table-layout:fixed;word-wrap: break-word;">
<tbody><tr><td width="61px;" class="blog-avatar"><img src="/icon/npcanhbakhia.gif"></td>
<td style="vertical-align: bottom;"><table cellpadding="0" cellspacing="0">
<tbody>
<tr><td class="current-blog" rowspan="2" style=""><div class="blog-bg-left"><img src="/giaodien/images/left-blog.png"></div><img style="vertical-align:middle;" title=" is online" src="/images/on.png" alt="online"> <font color="red"><b>Anh ba khía</b></font><div class="text">
<div class="omenu"><a href="nhakho.php">Kho cá</a></div>
<div class="omenu"><a href="rename.php">Đổi tên Nick</a></div>
<div class="omenu"><a href="phuthuy.php">In đậm nick</a></div>
</div></td></tr></tbody></table></td></tr></tbody></table></div>';
require('../../incfiles/end.php');
?>