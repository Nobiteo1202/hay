<?php
define('_IN_JOHNCMS', 1);
$headmod = 'khusinhthai';
require ('../../incfiles/core.php');
$textl = 'Bảng xếp hạng câu cá';
require ('../../incfiles/head.php');
echo'<div class="main-xmenu">';
echo '<div class="login"><details><summary><font color="red"><b>Thông tin chi tiết về BXH câu cá</b></font></summary> <b><div style="position:absolute;margin:-6px 0 0 235px"><img src="/icon/iconxoan/bangvang.png"></div><center><font color="red">top 1:<img src="/images/shopicon/cauca1.gif"><br/><font color="red">top 2:</font><img src="/images/shopicon/cauca2.gif"><br/><font color="red">top 3:<img src="/images/shopicon/cauca3.gif"></font></b></center></br></details></font></div>';
echo'<div class="danhmuc">Top câu cá</div>';
echo'<div class="menu list-bottom congdong"><img src="'.$home.'/icon/user.png" alt="icon" style="vertical-align: -3px;"/> Xu: '.$datauser[xu].' - Câu được: '.$datauser[soca].' con cá </div>'; 
$tongso = mysql_result(mysql_query("SELECT COUNT(*) FROM `users` WHERE `soca` > '0'"), 0);
$req = mysql_query("SELECT * FROM `users` WHERE `soca` > '0' ORDER BY `soca` DESC LIMIT $start, $kmess");
while ($res = mysql_fetch_array($req)) {
echo '<div class="menu list-bottom"><img src="'.$home.'/avatar/'.$res['id'].'.png" alt="'. $user['name'] . '" class="avatar_vina"/>
<a href="/member/'.$res['id'].'.html"><b>'.nick($res['id']).'</b></a><br/>
Câu được: '.$res['soca'].' con cá<br/><br/></div>';
}
if ($tongso > $kmess) {
echo '<div class="menu">' . functions::display_pagination('/khugiaitri/cauca/bangxephang.php?', $start, $tongso, $kmess) . '</div>';
}
echo'</div>';
require ('../../incfiles/end.php');
?>