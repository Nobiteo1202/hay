<?php
//Code by cRoSsOver
//Facebook: https://web.facebook.com/duyloc.2001
define('_IN_JOHNCMS', 1);
require_once('../../incfiles/core.php');
$textl = 'Khu sinh thái';
require('../../incfiles/head.php');
if(!$user_id){
echo '<div class="mainblok">
<div class="danhmuc"><b>Lỗi Truy Cập</b></div>';
echo '<div class="menu list-top">Vui lòng đăng nhập để sử dụng tính năng này!</div>';
echo '</div>';
require('../../incfiles/end.php');
exit;
}
$prov = mysql_num_rows(mysql_query("SELECT `id` FROM `fish` WHERE `user_id` = '".$user_id."' LIMIT 1"));
if($prov < 1){
    mysql_query("INSERT INTO `fish` SET 
    `name` = '".$login."',
    `user_id` = '".$user_id."',
    `lvl` = '0',
    `money` = '400',
    `time` = '0',
    `vsego` = '0',
    `rand_time` = '0',
    `status` = '0',
    `loc` = '0',
    `kg` = '0',
    `sorv` = '0'
    ");
    
    mysql_query("INSERT INTO `fish_in` SET 
    `user_id` = '".$user_id."',
    `ud` = '0',
    `ud_d` = '0',
    `kr` = '0',
    `kr_d` = '0',
    `ka` = '0',
    `ka_d` = '0',
    `na` = '0',
    `na_d` = '0'
    ");
}

mysql_query("UPDATE `fish` SET `time` = '0', `rand_time` = '0', `status` = '0' WHERE `user_id` = '".$user_id."' LIMIT 1");
mysql_query("UPDATE `users` SET `cancau`='".$datauser[savecancau]."',`docamtay`='0' WHERE `id`='".$user_id."'");
$act = $_GET['act'];
switch ($act) {
default:
?>
<div class="phdr"><center> Câu Cá </center></div>
<div class="mainblok">
<div class="honuoc">
<div class="vaocau">
<br>
<a href="fish.php">
<img src="img/vao.gif">
</a>
</div>
</div>
<?
 echo '<div class="da">';
//--code này copy để hiện avatar by cRoSsOver--//
//update nơi đang online và tọa độ
mysql_query("UPDATE `vitri` SET `time`='".time()."',`online`='".$textl."',`toado`='".$toado."' WHERE `user_id`='".$user_id."'");
$time=time()-300;
//bắt đầu cho hiện avatar
$req=mysql_query("SELECT * FROM `vitri` WHERE `online`='".$textl."' AND `time`>'".$time."'");
echo '<center><a href="/khugiaitri/cauca/anhbakhia.php"><img src="/icon/npcanhbakhia.gif"></a><a href="shop.php"><img src="img/shopcauca.png" alt="shopcauca"></a> 
<a href="bangxephang.php"><img src="img/bxh.png" alt="bxh" style="vertical-align: 4px;"></a> 
 <img src="img/den.png" alt="den" style="vertical-align: 4px;"></center>';
while($pr = mysql_fetch_array($req))
    {
$name=mysql_fetch_array(mysql_query("SELECT * FROM `users` WHERE `id`='".$pr[user_id]."'"));
$flip=rand(1,2);
if($flip==1) {$flip=' class="flip"';}
else {$flip='';}
        echo '<a href="/member/'.$pr['user_id'].'.html"><label style="display: inline-block;text-align: center;"><b style="font-size: 9px;color:red;font-weight:bold;text-align: center;">'.$name[name].'</b><br><img src="/avatar/'.$pr[user_id].'.png"></label></a>';
    }
//end avatar
echo'</div></div>';
break;
case 'cauca':
?>
<div class="mainblok">
<div class="honuoccauca">
<div class="datcauca">
<a href="?act=batdau">
<form method="post">
<input type="submit" name="batdau" value="Bắt đầu">
</form></a>
<img src="<?echo '/avatar/' . $datauser['id'] . '.png" alt="' . $datauser['name'] . '"';?> style="vertical-align: 20px;">
</div>
</div>
</div>
<?
if(isset($_POST['batdau'])) {
echo '<META HTTP-EQUIV="refresh" CONTENT="0; URL=index.php?act=batdau">';
}
break;
case 'batdau':
?>
<div class="mainblok">
<div class="honuoccauca">
<div class="ngoicau">
<img src="<?echo '/avatar/' . $datauser['id'] . '.png" alt="' . $datauser['name'] . '"';?> style="vertical-align: 20px;">
</div></div>
<?php
echo '<form method="post">';
echo '<select name="cancau">';
$cc1=mysql_fetch_array(mysql_query("SELECT * FROM `fish_ruong` WHERE `user_id`='".$user_id."' AND `id_loai`='1' AND `loai`='cancau'"));
$cc2=mysql_fetch_array(mysql_query("SELECT * FROM `fish_ruong` WHERE `user_id`='".$user_id."' AND `id_loai`='2' AND `loai`='cancau'"));
$cc3=mysql_fetch_array(mysql_query("SELECT * FROM `fish_ruong` WHERE `user_id`='".$user_id."' AND `id_loai`='3' AND `loai`='cancau'"));
if ($cc1[doben]>0) {
echo '<option value="1"> Cần câu tre ['.$cc1[doben].'%]</option>';
}
if ($cc2[doben]>0) {
echo '<option value="2"> Cần câu sắt ['.$cc2[doben].'%]</option>';
}
if ($cc3[doben]>0) {
echo '<option value="3"> Cần câu VIP ['.$cc3[doben].'%]</option>';
}
if ($cc1[doben]==0&&$cc2[doben]==0&$cc3[doben]==0) {
echo '<option> Chưa có cần câu!</option>';
}
echo '</select>';
echo '<select name="moicau">';
$moi1=mysql_fetch_array(mysql_query("SELECT * FROM `fish_ruong` WHERE `user_id`='".$user_id."' AND `id_loai`='1' AND `loai`='moicau'"));
$moi2=mysql_fetch_array(mysql_query("SELECT * FROM `fish_ruong` WHERE `user_id`='".$user_id."' AND `id_loai`='2' AND `loai`='moicau'"));
$moi3=mysql_fetch_array(mysql_query("SELECT * FROM `fish_ruong` WHERE `user_id`='".$user_id."' AND `id_loai`='3' AND `loai`='moicau'"));
if ($moi1[doben]>0) {
echo '<option value="1"> Mồi cơm ['.$moi1[doben].' mồi]</option>';
}
if ($moi2[doben]>0) {
echo '<option value="2"> Mồi trùng ['.$moi2[doben].' mồi]</option>';
}
if ($moi3[doben]>0) {
echo '<option value="3"> Mồi trứng kiến ['.$moi3[doben].' mồi]</option>';
}
if ($moi1[doben]==0&&$moi2[doben]==0&$moi3[doben]==0) {
echo '<option> Chưa có mồi!</option>';
}
echo '</select>';
echo '<input type="submit" name="dicau" value="Câu">';
echo '</form></div>';
if(isset($_POST['giang'])) {
echo '<META HTTP-EQUIV="refresh" CONTENT="0; URL=index.php?act=giang">';
}
break;
case 'giang':
?>
<div class="mainblok">
<div class="honuoccauca">
<div class="ngoicau">
<img src="<?echo '/avatar/' . $datauser['id'] . '.png" alt="' . $datauser['name'] . '"';?> style="vertical-align: 20px;">
<img src="img/giangcau.png" alt="icon" style="vertical-align: 8px;">
<form method="post">
<input type="submit" name="cau" value="Giật">
</form>
</div></div></div>
<?
break;
}
require('../../incfiles/end.php');
?>